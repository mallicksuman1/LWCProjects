import { LightningElement, track } from 'lwc';
import getAppointmentWrapper from '@salesforce/apex/GetAppointmentSlotsUsingAPI.getAppointmentWrapper';
import scheduleAppointmentOnSelectedDate from '@salesforce/apex/GetAppointmentSlotsUsingAPI.scheduleAppointmentOnSelectedDate';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';

export default class GetSlotsLwc extends LightningElement {
    @track subject;
    @track esp;
    @track dd;
    @track slotsList;
    @track slotsString;
    @track saId;

    subjectChange(event){
        this.subject = event.target.value;
    }
    espChange(event){
        this.esp = event.target.value;
    }
    ddChange(event){
        this.dd = event.target.value;
    }

    getSlotsService(){
        getAppointmentWrapper({subject:this.subject, espDate:this.esp, dueDate:this.dd})
        .then((data)=> {
            console.log('String Data '+data);
            
            const slots = JSON.parse(data);
            this.slotsList = slots;
            this.slotsString = data;
            this.saId = slots[0].saId;

            console.log('SA Id '+saId);
            /*if(slots){
                for(let slot of slots){
                    console.log('Slot Start '+slot.grade);
                    console.log('Slot Finish '+slot.startTime);
                    console.log('Slot Grade '+slot.endTime);
                }
            }*/

        })
        .catch((error)=> JSON.stringify(error));
    }


    scheduleSA(event){
        this.selectedSlot = event.currentTarget.dataset.id;

        scheduleAppointmentOnSelectedDate({arrivalStartDate:this.selectedSlot, saId:this.saId})
        .then((data) => {
            const event = new ShowToastEvent({
                title: 'Success',
                message:
                    'Appointment Scheduled Successfully',
                variant: 'success',
                mode: 'dismissable'
            });
            this.dispatchEvent(event);
        })
        .catch((error) => {JSON.stringify(error)
            const event = new ShowToastEvent({
                title: 'Failed',
                message:
                    'Failed to Schedule Appointment',
                variant: 'error',
                mode: 'dismissable'
            });
            this.dispatchEvent(event);
        });
    }
}