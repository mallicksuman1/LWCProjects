import { LightningElement } from 'lwc';
import getWeatherByCity from '@salesforce/apex/WeatherAPI.getWeatherByCity';

export default class GetWeaterByCity extends LightningElement {
    city;
    condition;
    iconURL;
    temp;
    feelsLike;

    handleCityChange(event){
        this.city = event.target.value;
    }

    handleClick(){
        getWeatherByCity({cityName : this.city}).then((response) => {
            console.log('##Output = '+ JSON.stringify(response));
            let parsedData = JSON.parse(response);
            this.condition = parsedData.current.condition.text;
            this.iconURL = parsedData.current.condition.icon;
            this.temp = parsedData.current.temp_c;
            this.feelsLike = parsedData.current.feelslike_c;
            }
        ).catch((error)=> {
            this.condition = 'No matching location was found';
            console.log('##Error = '+ JSON.stringify(error));
        }
        );
    }
}