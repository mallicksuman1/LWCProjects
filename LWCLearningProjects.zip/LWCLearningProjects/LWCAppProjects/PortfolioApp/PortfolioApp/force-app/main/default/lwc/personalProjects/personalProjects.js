import { LightningElement, api } from 'lwc';

export default class PersonalProjects extends LightningElement {
    @api projectDetails;
    
}