import { LightningElement, api } from 'lwc';

export default class EducationComponent extends LightningElement {
    @api educationDetails;
}