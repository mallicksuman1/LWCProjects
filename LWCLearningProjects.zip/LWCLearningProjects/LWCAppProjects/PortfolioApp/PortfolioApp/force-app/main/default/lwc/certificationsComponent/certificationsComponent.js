import { LightningElement, api } from 'lwc';

export default class CertificationsComponent extends LightningElement {
    @api portfolioDetails;
    
}