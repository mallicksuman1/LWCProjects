import { LightningElement, wire } from 'lwc';
import PROFILE_IMAGE from '@salesforce/resourceUrl/ProfileImage';
import getPortfolioDetails from '@salesforce/apex/PortfolioDetailsOperation.getPortfolioDetails';
import getEducationDetails from '@salesforce/apex/PortfolioDetailsOperation.getEducationDetails';
import getWorkExperienceDetails from '@salesforce/apex/PortfolioDetailsOperation.getWorkExperienceDetails';
import getProjectDetails from '@salesforce/apex/PortfolioDetailsOperation.getProjectDetails';

export default class HeaderSection extends LightningElement {
    imageUrl = PROFILE_IMAGE + '/ProfileImage/Suman_Image.jpg';
    portfolioDetails;
    educationDetails;
    workExpDetails;
    projectDetails;

    //Wired Methods to fetch all data starts
    @wire(getPortfolioDetails)
    getPortfolioDetails({data,error}){
        if(error){
            console.log('Error = '+error);
        }
        else if(data){
            console.log('Data = '+JSON.stringify(data));
            this.portfolioDetails = data;
        }
    }

    @wire(getEducationDetails)
    getEducationDetails({data,error}){
        if(error){
            console.log('Error = '+error);
        }
        else if(data){
            console.log('Data = '+JSON.stringify(data));
            this.educationDetails = data;
        }
    }

    @wire(getWorkExperienceDetails)
    getWorkExperienceDetails({data,error}){
        if(error){
            console.log('Error = '+error);
        }
        else if(data){
            console.log('Data = '+JSON.stringify(data));
            this.workExpDetails = data;
        }
    }

    @wire(getProjectDetails)
    getProjectDetails({data,error}){
        if(error){
            console.log('Error = '+error);
        }
        else if(data){
            console.log('Data = '+JSON.stringify(data));
            this.projectDetails = data;
        }
    }
    //Wired Methods to fetch all data ends

    //Color Codes -> #0C243C, #55C2C3, #C9D1D5, #7E8C9C
}