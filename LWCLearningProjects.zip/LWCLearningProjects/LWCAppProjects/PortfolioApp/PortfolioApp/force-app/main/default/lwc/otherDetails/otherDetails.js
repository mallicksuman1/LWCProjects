import { LightningElement, api } from 'lwc';

export default class OtherDetails extends LightningElement {
    @api portfolioDetails;
}