import { LightningElement, api } from 'lwc';

export default class SkillsComponent extends LightningElement {
    @api portfolioDetails;
}