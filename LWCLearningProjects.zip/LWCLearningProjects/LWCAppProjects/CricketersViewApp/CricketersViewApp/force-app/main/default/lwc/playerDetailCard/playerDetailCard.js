import { LightningElement, wire } from 'lwc';
import { subscribe, MessageContext } from 'lightning/messageService';
import MESSAGE_CHANNEL_PLAYER from '@salesforce/messageChannel/PlayerData__c';
//import NavigationMixin from 'lightning/navigation';
import getPlayerById from '@salesforce/apex/CricketerApp.getPlayerById';
import { NavigationMixin } from 'lightning/navigation';

export default class PlayerDetailCard extends NavigationMixin(LightningElement) {

    @wire(MessageContext)
    messageContext;

    playerData;

    selectedPlayerId;
    connectedCallback(){
        subscribe(this.messageContext, MESSAGE_CHANNEL_PLAYER, 
            (message) => this.handleSelectedCricketer(message.PlayerId));

        
    }

    handleSelectedCricketer(cricketerId){
        this.selectedPlayerId = cricketerId;

        getPlayerById({playerId : cricketerId})
        .then(result => this.playerData = result)
        .catch(error => console.log('Error Detail '+JSON.stringify(error)));
    }

    handlePreviewClick(){
            this[NavigationMixin.Navigate]({
                type: 'standard__recordPage',
                attributes: {
                    recordId: this.selectedPlayerId,
                    objectApiName: 'Cricketer__c',
                    actionName: 'view'
                },
            });
        
    }
}