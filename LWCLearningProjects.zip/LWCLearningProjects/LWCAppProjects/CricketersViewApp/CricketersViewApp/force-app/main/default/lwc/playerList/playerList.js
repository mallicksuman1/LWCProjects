import { LightningElement, api, wire } from 'lwc';
import getPlayers from '@salesforce/apex/CricketerApp.getPlayers';
import getPlayersByNationality from '@salesforce/apex/CricketerApp.getPlayersByNationality';
import { publish, MessageContext } from 'lightning/messageService';
import MESSAGE_CHANNEL_PLAYER from '@salesforce/messageChannel/PlayerData__c';

export default class PlayerList extends LightningElement {
    @api nationalityValue;
    playersData;
    selectedPlayerId='';
    selectedNationality = '';
    @api findPlayersByNationality(nationality){
        console.log('Child Nationality - '+nationality);
        this.selectedNationality = nationality;
        //getPlayersByNationality({nationality: nationality}).then(result => 
            //this.playersData = result).catch(error => console.log('Error - '+error));
    }

    @wire(MessageContext)
    messageContext;

    @wire(getPlayers, {nationality: '$selectedNationality'})
    getPlayersData({data,error}){
        if(error){
            console.log('Error '+JSON.stringify(error));
        }
        else if(data){
            console.log('Players Data - '+JSON.stringify(data));
            console.log('nationalityValue - '+JSON.stringify(this.nationalityValue));
            this.playersData = data;
        }
    }

    handleCardClick(event){
        this.selectedPlayerId = event.currentTarget.dataset.id;
        console.log('this.selectedPlayerId = '+this.selectedPlayerId);

        publish(this.messageContext, MESSAGE_CHANNEL_PLAYER, {PlayerId : this.selectedPlayerId});

        let selectedElem = this.template.querySelectorAll('.selected');
        if(selectedElem.length > 0){
            selectedElem[0].classList.remove('selected');
        }
        let newElem = this.template.querySelector(`[data-id="${this.selectedPlayerId}"]`);
        if(newElem){
            newElem.className = 'title-wrapper selected';
        }

        const selectedEvent = new CustomEvent("playernamechange", {
            detail: this.selectedPlayerId
          });
      
          // Dispatches the event.
          this.dispatchEvent(selectedEvent);
    }
}