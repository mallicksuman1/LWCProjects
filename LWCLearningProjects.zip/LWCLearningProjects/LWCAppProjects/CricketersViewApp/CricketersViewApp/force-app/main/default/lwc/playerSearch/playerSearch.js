import { LightningElement,track,wire } from 'lwc';
import { NavigationMixin } from 'lightning/navigation';
import { getObjectInfo, getPicklistValues } from 'lightning/uiObjectInfoApi';
import CRICKETER_OBJECT from '@salesforce/schema/Cricketer__c';
import NATIONALITY_FIELD from '@salesforce/schema/Cricketer__c.Nationality__c';

export default class PlayerSearch extends NavigationMixin(LightningElement) {

    handleNewPlayer(){
    this[NavigationMixin.Navigate]({
        type: 'standard__objectPage',
        attributes: {
            objectApiName: 'Cricketer__c',
            actionName: 'new'
        },
    });
    }
    value ='';
    recordTypeId;
    picklistOptions=[{label:'None', value:'None'}];
    @wire(getObjectInfo, { objectApiName: CRICKETER_OBJECT })
    cricketerMetadata({data,error}){
        if(error){
            console.log('Error '+JSON.stringify(error));
        }
        else if(data){
            console.log('Data - '+JSON.stringify(data));
            this.recordTypeId = data.defaultRecordTypeId;
            console.log('defaultRecordTypeId - '+this.recordTypeId);
        }
    };
    // now get the industry picklist values

    @wire(getPicklistValues,
        {
            recordTypeId: '$recordTypeId', 
            fieldApiName: NATIONALITY_FIELD
        }
    )
    cricketerPicklist({data,error}){
        if(error){
            console.log('Error '+JSON.stringify(error));
        }
        else if(data){
            console.log('Picklist Data - '+JSON.stringify(data));
            this.picklistOptions = data.values;
        }
    };
    // on select picklist value to show the selected value
    handleChange(event) {
        this.value = event.detail.value;
        this.template.querySelector('c-player-list').findPlayersByNationality(this.value);
    }
    connectedCallback(){
        console.log(this.cricketerPicklist);
    }

    @track playerNameValue = '';
    hanldePlayerNameChange(event) {
        this.playerNameValue = event.detail;
    }
}