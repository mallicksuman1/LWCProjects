import { LightningElement, api } from 'lwc';
import { NavigationMixin } from 'lightning/navigation';

export default class SinglePokemon extends NavigationMixin(LightningElement) {
    @api pokemondet;
    @api recordId;
    connectedCallback(){
        console.log('pokemon = '+JSON.stringify(this.pokemondet));
    }
    handleClick(){
        console.log('pokemon = '+JSON.stringify(this.pokemondet));
        console.log('pokemon Id = '+JSON.stringify(this.recordId));
        this[NavigationMixin.Navigate]({
            type: "standard__recordPage",
            attributes: {
              objectApiName: "Pokemon__c",
              actionName: "view",
              recordId: this.recordId
            }
          });
    }
}