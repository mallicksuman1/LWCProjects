import { LightningElement, api, wire } from 'lwc';
import { getRecord,getFieldValue } from 'lightning/uiRecordApi';
import TRAINER_ID from '@salesforce/schema/Pokemon__c.Trainer__c';

const fields = [TRAINER_ID];
export default class TrainerComponent extends LightningElement {
    
    @api recordId;
    @wire(getRecord, {recordId : '$recordId', fields : fields})
    pokemons;

    get trainerRecordId(){
        return getFieldValue(this.pokemons.data, TRAINER_ID);
    }
}