import { LightningElement, wire, api } from 'lwc';
import { getRecord, getFieldValue } from 'lightning/uiRecordApi';

const NAME = 'Pokemon__c.Name';
const LATITUDE = 'Pokemon__c.Location__Latitude__s';
const LONGITUDE = 'Pokemon__c.Location__Longitude__s';
const pokemonFields = [NAME,LATITUDE,LONGITUDE];
export default class MapComponent extends LightningElement {
    @api recordId;
    pokemon = [];
    mapMarkers = [];
    name = '';

    
    @wire(getRecord, {recordId : '$recordId', fields : pokemonFields})
    getPokemonData({data,error}){
        if(data){
            this.name = getFieldValue(data, NAME);
            const Latitude = getFieldValue(data, LATITUDE);
            const Longitude = getFieldValue(data, LONGITUDE);
            this.mapMarkers = [{
                location : {Latitude,Longitude},
                title : this.name,
                description : 'Pokemon Location'
            }];
            console.log('data = '+data + this.name);
        }
        else if(error){
            console.error('Error Occured '+error);
        }
    }
}