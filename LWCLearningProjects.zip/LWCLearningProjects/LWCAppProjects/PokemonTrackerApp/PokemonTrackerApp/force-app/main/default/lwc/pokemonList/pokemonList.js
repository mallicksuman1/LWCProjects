import { LightningElement } from 'lwc';
import getPokemons from '@salesforce/apex/PokemonTracker.getPokemons'

export default class PokemonList extends LightningElement {

    error;
    pokemons;
    selectedPokemon;
    connectedCallback(){
        getPokemons()
        .then(result => {this.pokemons = result;
            console.log(this.pokemons)})
        .catch( error => {console.log(error); this.error=error});
    }
    
}