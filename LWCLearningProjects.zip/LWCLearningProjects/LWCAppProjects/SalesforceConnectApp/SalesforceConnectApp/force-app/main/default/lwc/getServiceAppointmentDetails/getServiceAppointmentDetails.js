import { LightningElement, wire } from 'lwc';
import getServiceAppointments from '@salesforce/apex/SalesforceConnectIntegration.getServiceAppointments';

export default class GetServiceAppointmentDetails extends LightningElement {
    serviceAppointments = [];
    @wire(getServiceAppointments)
    getServices({data, error}){
        if(error){
            console.log('Error -'+ error);
        }
        else if(data){
            console.log('Data -'+ JSON.stringify(data));
            this.serviceAppointments = data;
        }
    }
}